CREATE FUNCTION getChildList(rootId VARCHAR(100))
  RETURNS LONGTEXT
  BEGIN
    DECLARE str LONGTEXT;
    DECLARE cid LONGTEXT;
    SET str = '$';
    SET cid = rootId;
    WHILE cid IS NOT NULL DO
      SET str = CONCAT(str, ',', cid);
      SELECT GROUP_CONCAT(id) into cid FROM sys_dept WHERE FIND_IN_SET(parent_id, cid) > 0;
#       SELECT GROUP_CONCAT(id) INTO cid FROM treeNodes WHERE FIND_IN_SET(parent_id, cid) > 0;
    END WHILE;
    RETURN str;
  END;
