CREATE FUNCTION getChilds(parentId INT)
  RETURNS VARCHAR(1000)
  BEGIN
    DECLARE ret VARCHAR(1000);
    declare ct VARCHAR(1000);
    declare pid int(11);
    /*首先这里对游标进行定义*/
    DECLARE  cur_ids CURSOR FOR SELECT id FROM sys_dept a WHERE a.parent_id = parentId;
    OPEN  cur_ids; /*接着使用OPEN打开游标*/
    out_loop:LOOP
    FETCH  cur_ids INTO pid; /*把第一行数据写入变量中,游标也随之指向了记录的第一行*/
      SELECT group_concat(id) into ct FROM sys_dept a WHERE a.parent_id = pid;
    set ret=concat(ret,',',ct);
    FETCH  cur_ids INTO pid;
    END LOOP out_loop;
    CLOSE  cur_ids;  /*用完后记得用CLOSE把资源释放掉*/
    RETURN ret;
  END;
